Strict scanner package

Содержимое архива:
- tools/tpl/run_strict_scanner.py
- tools/tpl/debug_run_postfilter.py
- tools/tpl/debug_metrics_yantar.py
- tools/tpl/debug_crop_logger.py
- tools/tpl/overlay_matcher.py
- tools/cfg/config.json

Запуск (пример для Windows PowerShell):
```powershell
# активируйте виртуальное окружение, если нужно
& C:/bot/.venv/Scripts/Activate.ps1
python -m pip install --upgrade pip
python -m pip install opencv-python pillow numpy

# запустить проверку для образа yantar
C:/bot/.venv/Scripts/python.exe "c:\bot\tools\tpl\run_strict_scanner.py" --image "C:\bot\back\screens\yantar.png" --out "C:\bot\debug\out_icons_debug" --use-overlay-verify --use-candidates --min-combined 0.80 --debug-all-matches
```

Где смотреть результаты:
- Отчёты: `C:\bot\debug\out_icons_debug\strict_report_<screen>.json`
- CSV: `C:\bot\debug\out_icons_debug\strict_matches_<screen>.csv`
- Overlays: `C:\bot\debug\out_icons_debug\strict_overlay_<screen>.png`
- Debug-crops: `C:\bot\debug\out_icons_debug\crops\<screen>\<tpl_key>\`

Примечания:
- В `tools/cfg/config.json` есть пер-template override для `Янтарь_icon`.
- Если получатель не хочет устанавливать GUI-версию OpenCV, можно поставить `opencv-python-headless`.
